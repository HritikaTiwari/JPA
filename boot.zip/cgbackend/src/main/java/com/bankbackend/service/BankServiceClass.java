package com.bankbackend.service;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bankbackend.dao.TransactionRepo;
import com.bankbackend.dao.UsersRepo;
import com.bankbackend.entities.TransactionBean;
import com.bankbackend.entities.UserBean;
import com.bankbackend.exceptions.GlobalException;
import com.bankbackend.exceptions.InvalidAuthentication;


@Service("BankService")
public class BankServiceClass implements BankServiceInterface {
	
	
	@Autowired
	private UsersRepo userDao;
	
	@Autowired
	private TransactionRepo transDao;
	
	
	public TransactionBean createTransactions(String transactionType,int amount) {
		TransactionBean tb = new TransactionBean();
		Date date= new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		tb.setAmount(amount);
		tb.setTransactionDate(ts);
		tb.setTransactionType(transactionType);
		
		return tb;
		
	}
	

	@Override
	public UserBean userAccountCreate(UserBean ub) {
		if(!ub.getMobileNumber().matches("[6-9][0-9]{9}")) {
			throw new GlobalException("Invalid Mobile Nunber"); 	
		}
		return userDao.save(ub);
	}

	@Override
	public int depositAmount(UserBean ub) {
		
		if(userDao.existsById(ub.getAccountId()) && ub.getBalance() > 0) {
			
			Optional<UserBean> optionalUb = userDao.findById(ub.getAccountId());
			UserBean dataBaseUb = optionalUb.get();
			int total = ub.getBalance() + dataBaseUb.getBalance();
			dataBaseUb.setBalance(total);
			
			TransactionBean tb = createTransactions("Deposit", ub.getBalance());
			
			dataBaseUb.addTransactions(tb);	
			
			transDao.save(tb);
			userDao.save(dataBaseUb);
		
			
			return total;
			
		}
		
		return -1;
	}

	@Override
	public int withdrawAmount(UserBean ub) {
		if(userDao.existsById(ub.getAccountId())) {
			
			Optional<UserBean> optionalUb = userDao.findById(ub.getAccountId());
			UserBean dataBaseUb = optionalUb.get();
			
			if(ub.getBalance() > dataBaseUb.getBalance()) {
				throw new GlobalException("Insufficient Balance");
			}
			
			int total = dataBaseUb.getBalance() - ub.getBalance();
			dataBaseUb.setBalance(total);
			
			TransactionBean tb = createTransactions("Withdraw", ub.getBalance());
			
			dataBaseUb.addTransactions(tb);
			transDao.save(tb);
			userDao.save(dataBaseUb);
			
			
			return total;
			
		}
		
		return -1;
		
	}

	@Override
	public int showBalance(int accId) {
		if(userDao.existsById(accId)) {
			
			Optional<UserBean> optionalUb = userDao.findById(accId);
			UserBean dataBaseUb = optionalUb.get();
			return dataBaseUb.getBalance();
			
		}
		
		return -1;
	}
	
	

	@Override
	public int fundTransfer(int accountId, UserBean ub) {
	boolean flag = false;	
	boolean isTransferSucess = false;
	int totalAmt = 0;
	int globalId = ub.getAccountId();
	if(userDao.existsById(ub.getAccountId())) {
			
			Optional<UserBean> optionalUb = userDao.findById(ub.getAccountId());
			UserBean dataBaseUb = optionalUb.get();
			
			if(ub.getBalance() > dataBaseUb.getBalance()) {
				throw new GlobalException("Insufficient Balance");
			}
			
			int total = dataBaseUb.getBalance() - ub.getBalance();
			dataBaseUb.setBalance(total);
			
			totalAmt = total;
			flag = true;
			
			TransactionBean tb = createTransactions("Fund Transfer To", ub.getBalance());			
			tb.setToAccountId(accountId);
			
			dataBaseUb.addTransactions(tb);
			transDao.save(tb);
			userDao.save(dataBaseUb);
			
	}
	if(userDao.existsById(accountId)&& flag) {
		
		Optional<UserBean> optionalUb = userDao.findById(accountId);
		UserBean dataBaseUb = optionalUb.get();
		int total = ub.getBalance() + dataBaseUb.getBalance();
		dataBaseUb.setBalance(total);
		userDao.save(dataBaseUb);
		isTransferSucess = true;	
		
		TransactionBean tb = createTransactions("Fund Transfer From", ub.getBalance());	
		tb.setToAccountId(globalId);
		
		dataBaseUb.addTransactions(tb);
		transDao.save(tb);
		userDao.save(dataBaseUb);
		
	}
	if(isTransferSucess) {
		return totalAmt;
	}
	else {
		return -1;
	}
	
	}
	
	
	

	@Override
	public Set<TransactionBean> transactionList(int accountId)  {
		
		if(userDao.existsById(accountId)) {
			Optional<UserBean> optionalUb = userDao.findById(accountId);
			UserBean dataBaseUb = optionalUb.get();
			System.out.println(dataBaseUb.getTransactions());
			return dataBaseUb.getTransactions();
		}
		throw new GlobalException("account not found");
	}

	@Override
	public UserBean signIn(int accId, String accPassword)  {
		
		if(userDao.existsById(accId)) {
			Optional<UserBean> optionalUb = userDao.findById(accId);
			UserBean dataBaseUb = optionalUb.get();
			if(dataBaseUb.getAccountPassword().equals(accPassword)) {
				return dataBaseUb;
			}
			else {
				throw new InvalidAuthentication("Password Not Matched");
			}
		}
		
		throw new InvalidAuthentication("Account Not Found");
	}

	



}
