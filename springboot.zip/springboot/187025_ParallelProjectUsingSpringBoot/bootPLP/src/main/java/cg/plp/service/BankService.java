package cg.plp.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cg.plp.dao.TransactionRepo;
import cg.plp.dao.UsersRepo;
import cg.plp.entities.TransactionBean;
import cg.plp.entities.UserBean;
import cg.plp.exception.GlobalException;
import cg.plp.exception.InvalidAuthentication;

@SuppressWarnings("unused")
@Service("BankService")
public class BankService implements IBankService {

	@Autowired
	private UsersRepo uDao;

	@Autowired
	private TransactionRepo tDao;

	public TransactionBean createTransactions(String transactionType, int amount) {
		TransactionBean tb = new TransactionBean();
		Date date = new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		tb.setAmount(amount);
		tb.setTransactionDate(ts);
		tb.setTransactionType(transactionType);

		return tb;

	}

	@Override
	public UserBean accountCreate(UserBean ub) {
		if (!ub.getMobileNumber().matches("[7-9][0-9]{9}")) {
			throw new GlobalException("Incorrect Mobile Nunber");
		}
		return uDao.save(ub);
	}

	@Override
	public int deposit(UserBean ub) {

		if (uDao.existsById(ub.getAccountId()) && ub.getBalance() > 0) {

			Optional<UserBean> optionalUb = uDao.findById(ub.getAccountId());
			UserBean dataBaseUb = optionalUb.get();
			int total = ub.getBalance() + dataBaseUb.getBalance();
			dataBaseUb.setBalance(total);

			TransactionBean tb = createTransactions("Deposit", ub.getBalance());

			dataBaseUb.addTransactions(tb);

			tDao.save(tb);
			uDao.save(dataBaseUb);

			return total;

		}

		return -1;
	}

	@Override
	public int withdraw(UserBean ub) {
		if (uDao.existsById(ub.getAccountId())) {

			Optional<UserBean> optionalUb = uDao.findById(ub.getAccountId());
			UserBean dataBaseUb = optionalUb.get();

			if (ub.getBalance() > dataBaseUb.getBalance()) {
				throw new GlobalException("Insufficient Balance");
			}

			int total = dataBaseUb.getBalance() - ub.getBalance();
			dataBaseUb.setBalance(total);

			TransactionBean tb = createTransactions("Withdraw", ub.getBalance());

			dataBaseUb.addTransactions(tb);
			tDao.save(tb);
			uDao.save(dataBaseUb);

			return total;

		}

		return -1;

	}

	@Override
	public int showBalance(int accId) {
		if (uDao.existsById(accId)) {

			Optional<UserBean> optionalUb = uDao.findById(accId);
			UserBean dataBaseUb = optionalUb.get();
			return dataBaseUb.getBalance();

		}

		return -1;
	}

	@Override
	public int fundTransfer(int accountId, UserBean ub) {
		boolean flag = false;
		boolean isTransferSucess = false;
		int totalAmt = 0;
		int globalId = ub.getAccountId();
		if (uDao.existsById(ub.getAccountId())) {

			Optional<UserBean> optionalUb = uDao.findById(ub.getAccountId());
			UserBean dataBaseUb = optionalUb.get();

			if (ub.getBalance() > dataBaseUb.getBalance()) {
				throw new GlobalException("Insufficient Balance");
			}

			int total = dataBaseUb.getBalance() - ub.getBalance();
			dataBaseUb.setBalance(total);

			totalAmt = total;
			flag = true;

			TransactionBean tb = createTransactions("Fund Transfer To", ub.getBalance());
			tb.setToAccountId(accountId);

			dataBaseUb.addTransactions(tb);
			tDao.save(tb);
			uDao.save(dataBaseUb);

		}
		if (uDao.existsById(accountId) && flag) {

			Optional<UserBean> optionalUb = uDao.findById(accountId);
			UserBean dataBaseUb = optionalUb.get();
			int total = ub.getBalance() + dataBaseUb.getBalance();
			dataBaseUb.setBalance(total);
			uDao.save(dataBaseUb);
			isTransferSucess = true;

			TransactionBean tb = createTransactions("Fund Transfer From", ub.getBalance());
			tb.setToAccountId(globalId);

			dataBaseUb.addTransactions(tb);
			tDao.save(tb);
			uDao.save(dataBaseUb);

		}
		if (isTransferSucess) {
			return totalAmt;
		} else {
			return -1;
		}

	}

	@Override
	public Set<TransactionBean> transactionList(int accountId) {

		if (uDao.existsById(accountId)) {
			Optional<UserBean> optionalUb = uDao.findById(accountId);
			UserBean dataBaseUb = optionalUb.get();
			System.out.println(dataBaseUb.getTransactions());
			return dataBaseUb.getTransactions();
		}
		throw new GlobalException("account not found");
	}

	@Override
	public UserBean logIn(int accId, String accPassword) {

		if (uDao.existsById(accId)) {
			Optional<UserBean> optionalUb = uDao.findById(accId);
			UserBean dataBaseUb = optionalUb.get();
			if (dataBaseUb.getAccountPassword().equals(accPassword)) {
				return dataBaseUb;
			} else {
				throw new InvalidAuthentication("Password Not Matched");
			}
		}

		throw new InvalidAuthentication("Account Not Found");
	}

}
