package cg.plp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootPlpApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootPlpApplication.class, args);
	}

}
