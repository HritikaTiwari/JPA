package cg.plp.exception;

@SuppressWarnings("serial")
public class GlobalException extends RuntimeException {

	public GlobalException(String msg) {
		super(msg);
	}

	public GlobalException() {
	}

}
