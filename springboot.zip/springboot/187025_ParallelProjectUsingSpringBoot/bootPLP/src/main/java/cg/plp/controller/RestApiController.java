package cg.plp.controller;

import java.util.Date;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import cg.plp.entities.TransactionBean;
import cg.plp.entities.UserBean;
import cg.plp.exception.GlobalException;
import cg.plp.service.BankService;

@SuppressWarnings("unused")
@RestController
@RequestMapping("/bank")
//@CrossOrigin(origins = "http://localhost:4200")
public class RestApiController {

	@Autowired
	private BankService service;

	@PostMapping(value = "/create")
	public UserBean addUserData(@RequestBody final UserBean usr) {
		return service.accountCreate(usr);
	}

	@PutMapping(value = "/deposit")
	public int depositAmount(@RequestBody final UserBean usr) {
		int i = service.deposit(usr);
		if (i == -1) {
			throw new GlobalException("Deposit Failed");
		}
		return i;
	}

	@PutMapping(value = "/withdraw")
	public int withdrawAmount(@RequestBody final UserBean usr) {
		int i = service.withdraw(usr);
		if (i == -1) {
			throw new GlobalException("Withdraw Failed");
		}
		return i;
	}

	@GetMapping(value = "/balance/{id}")
	public int showBalance(@PathVariable final int id) {
		int i = service.showBalance(id);
		if (i == -1) {
			throw new GlobalException("Failed");
		}
		return i;
	}

	@PutMapping(value = "/fundtransfer/{accountId}")
	public int fundTransfer(@PathVariable final int accountId, @RequestBody final UserBean usr) {
		int i = service.fundTransfer(accountId, usr);
		if (i == -1) {
			throw new GlobalException("Transfer Failed");
		}
		return i;
	}

	@GetMapping(value = "/transactions/{id}")
	public Set<TransactionBean> printTransaction(@PathVariable final int id) {
		return service.transactionList(id);
	}

	@GetMapping(value = "/logIn/id/{id}/password/{password}")
	public UserBean logIn(@PathVariable final int id, @PathVariable final String password) {
		return service.logIn(id, password);
	}

}
