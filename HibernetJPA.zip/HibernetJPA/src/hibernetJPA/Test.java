package hibernetJPA;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
public static void main(String args[]) {
		
		
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("a");
	EntityManager em =emf.createEntityManager();
	em.getTransaction().begin();
//	Employee e = new Employee(1213,"hritika",1000);
	Employee e = em.find(Employee.class, new Integer(1213));
	//em.persist(e);
	e.setEname("sharma ji");
//	em.merge(e);
	em.remove(e);
	em.getTransaction().commit();
    System.out.println("inserted");
	System.out.println("updated");	
	System.out.println("delete");	
}
}
