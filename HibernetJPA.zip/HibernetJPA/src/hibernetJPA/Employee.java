package hibernetJPA;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


	@Entity
	@Table(name="hritzz")
	public class Employee {
		public Employee() {
			super();
		}
		@Id
		@Column(name="eid",length=20)
	private int empid;
		@Column(name="ename", length=20)
	private String ename;
		@Column(name="salary", length=20)
	private int esal;
		public Employee(int empid, String ename, int esal) {
			super();
			this.empid = empid;
			this.ename = ename;
			this.esal = esal;
		}
		public int getEmpid() {
			return empid;
		}
		public void setEmpid(int empid) {
			this.empid = empid;
		}
		public String getEname() {
			return ename;
		}
		public void setEname(String ename) {
			this.ename = ename;
		}
		public int getEsal() {
			return esal;
		}
		public void setEsal(int esal) {
			this.esal = esal;
		}

	
}
