package com.bank.dao;

import java.util.HashMap;

import javax.persistence.EntityManager;

import com.bank.user.bean.TransactionBean;
import com.bank.user.bean.UserBean;



public class DaoClass implements DaoInterface {
	public DaoClass() {
		super();
		entityManager = JPAUtil.getEntityManager();
	}
	private EntityManager entityManager;
	

	@Override
	public String userAccountCreate(UserBean userbean) {
	entityManager.persist(userbean);
	return userbean.getAccountId();
	
	}

	@Override
	public int SignIn(String accountId, String accountPassword) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String showBalance(String accountId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String Deposit(String accountId, int amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String withDraw(String accountId, int amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String fundTransfer(String sourceAccountId, String destinationAccountId, int amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HashMap<Integer, TransactionBean> printTransactions(String accountId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean validAccountId(String accountId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean checkBalance(String accountId, int amount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void commitTransaction() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void beginTransaction() {
		// TODO Auto-generated method stub
		
	}
	
	
}
