package com.bank.user.bean;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="TBean")
public class TransactionBean {

	
	public TransactionBean() {
		super();
	}

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="tr_seq")
	@SequenceGenerator(name="tr_seq", initialValue=1000, allocationSize=1)
	@Column(name="transactionId",length=20)
	private int transactionId;
	@Column(name="transactionType", length=20)
	private String transactionType;
	@Column(name="toAccountId", length=20)
	private String toAccountId;
	@Column(name="transactionDate", length=20)
	private Timestamp transactionDate;
	@Column(name="amount", length=20)
	private int amount;
	@Column(name="accountId", length=20)
	private String accountId;
	
	//private UserBean userBean;


	public int getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}


	public String getTransactionType() {
		return transactionType;
	}


	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}


	public String getToAccountId() {
		return toAccountId;
	}


	public void setToAccountId(String toAccountId) {
		this.toAccountId = toAccountId;
	}


	public Timestamp getTransactionDate() {
		return transactionDate;
	}


	public void setTransactionDate(Timestamp getDate) {
		this.transactionDate = getDate;
	}


	public int getAmount() {
		return amount;
	}


	public void setAmount(int amount) {
		this.amount = amount;
	}


	public String getAccountId() {
		return accountId;
	}


	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	

}
