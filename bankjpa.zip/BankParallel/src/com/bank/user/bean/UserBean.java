package com.bank.user.bean;

import java.util.ArrayList;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="UBean")
public class UserBean {
	
	public UserBean() {
		super();
	}
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="user_seq")
	@SequenceGenerator(name="user_seq", initialValue=10000, allocationSize=1)
	@Column(name="accountid",length=20)
	private String accountId;
	@Column(name="accountPassword", length=20)
	private String accountPassword;
	@Column(name="name", length=20)
	private String name;
	@Column(name="mobileNumber", length=20)
	private long mobileNumber;
	@Column(name="Balance", length=20)
	private int Balance = 0;
	
	
	/*
	private ArrayList<String> tranactions = new ArrayList<String>();
	public ArrayList<String> getTransaction() {
		
		return tranactions;
	}
	public void setTransaction(String transaction) {
		tranactions.add(transaction);
	}
	
	*/
	
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getAccountPassword() {
		return accountPassword;
	}
	public void setAccountPassword(String accountPassword) {
		this.accountPassword = accountPassword;
	}
	public int getBalance() {
		return Balance;
	}
	public void setBalance(int balance) {
		Balance = balance;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	

	
	
}
