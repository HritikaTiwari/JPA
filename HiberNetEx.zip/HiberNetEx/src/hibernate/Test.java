package hibernate;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

public class Test {
	public static void main(String args[]) {
		
		
//		EntityManagerFactory emf=Persistence.createEntityManagerFactory("a");
//		EntityManager em =emf.createEntityManager();
//		em.getTransaction().begin();
//		Employee e = new Employee(1213,"hritika",1000);
//		em.getTransaction().commit();
//		System.out.println("inserted");
		
	Configuration cfg = new Configuration();
	cfg.configure();//to load configuration file

	SessionFactory factory = cfg.buildSessionFactory();

	Session session = factory.openSession();
	// dml
	Transaction tran = session.beginTransaction();

	Employee emp = (Employee) session.get(Employee.class, new Integer(123));
//	session.save(emp);//insert,ORM
//	emp.setEsal(450000);
//	session.update(emp);
//	tran.commit();
	session.delete(emp);
	tran.commit();

	//tran.commit();
   session.close();
	factory.close();
}
}